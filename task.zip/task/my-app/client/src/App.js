import React from 'react';
import Button from './Button';
import './App.css';

const App = () => {
  const handleSignup = () => {
    alert('Signup button clicked');
  };

  const handleSignin = () => {
    alert('Signin button clicked');
  };

  return (
    <div className="app-container">
      <h1>Welcome to My App</h1>
      <div className="button-container">
        <Button onClick={handleSignup}>Signup</Button>
        <Button onClick={handleSignin}>Signin</Button>
      </div>
    </div>
  );
};

export default App;
